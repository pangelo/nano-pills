#include "player.h"

#include "named_colors.h"

#include <ofGraphics.h>

player::player():
  m_pos (0,0),
  m_state (TARGET),
  m_payload(0)
{
}

player::~player()
{
}

void
player::update (float x, float y)
{
  if (m_state == TARGET) {
    m_pos.set (x, y);
  }
}

void
player::draw()
{
  if (m_state == DEPLOY) {
    // render explosions
    return;
  }

  ofVec2f p1 (m_pos.x - 20, m_pos.y - 10);
  ofVec2f p2 (m_pos.x + 20, m_pos.y - 10);
  ofVec2f p3 (m_pos.x + 20, m_pos.y + 10);
  ofVec2f p4 (m_pos.x - 20, m_pos.y + 10);

  ofSetColor (named_colors::white);
  ofSetLineWidth (1.0);
  ofNoFill();
  ofBeginShape();
  ofVertex (p1.x, p1.y);
  ofVertex (p2.x, p2.y);
  ofCurveVertex (p1.x, p1.y);
  ofCurveVertex (p2.x, p2.y);
  ofCurveVertex (p3.x, p3.y);
  ofCurveVertex (p4.x, p4.y);
  ofVertex (p3.x, p3.y);
  ofVertex (p4.x, p4.y);
  ofCurveVertex (p3.x, p3.y);
  ofCurveVertex (p4.x, p4.y);
  ofCurveVertex (p1.x, p1.y);
  ofCurveVertex (p2.x, p2.y);
  ofEndShape ();
}

void
player::deploy()
{
  m_state = DEPLOY;
}
