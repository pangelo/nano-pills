#include "pulsing_walls.h"
#include "named_colors.h"

#include <ofSoundPlayer.h>

pulsing_walls::pulsing_walls():
  m_walls(16),
  m_width (0.0f),
  m_height (0.0f),
  m_beat_displace (0.0f),
  m_thickness (30.0f),
  m_sensitivity (16)
{
}

pulsing_walls::~pulsing_walls()
{
}
  
void 
pulsing_walls::setup (float width, float height, int resolution)
{
  m_width = width;
  m_height = height;

  m_walls.resize (resolution);
  
  float min_displace = 5.0f;
  float max_displace = m_thickness;

  std::vector<int> line_dist (resolution);
  float max_dist = (width * 2) + (height * 2); 
  
  for (unsigned int i = 0; i < line_dist.size(); i++) {
    line_dist[i] = ofRandom (max_dist);
  }

  std::sort (line_dist.begin(), line_dist.end());
  
  
  unsigned int i = 0;
  while (line_dist[i] < width) {
    m_walls[i].x = line_dist[i];
    m_walls[i].y = ofRandom(min_displace, max_displace);
    i++;
  }

  while (line_dist[i] < (width + height)) {
    m_walls[i].x = width - ofRandom (min_displace, max_displace);
    m_walls[i].y = line_dist[i] - width;
    i++;
  }

  while (line_dist[i] < ((width * 2) + height)) {
    m_walls[i].x = width - (line_dist[i] - (width + height));
    m_walls[i].y = height - ofRandom (min_displace, max_displace);
    i++;
  }

  while (i < line_dist.size()) {
    m_walls[i].x = ofRandom (min_displace, max_displace);
    m_walls[i].y = height - (line_dist[i] - ((width * 2) + height));
    i++;
  }
}

void 
pulsing_walls::update()
{
  float * p_spectrum = ofSoundGetSpectrum (m_sensitivity);
  
  float sum = 0.0f;
  for (unsigned int i=0; i < m_sensitivity; i++) {
    sum += p_spectrum[i];
  }

  float diff = sum - m_beat_displace;
  m_beat_displace = m_beat_displace + (diff / 2.0f);
}
 
void 
pulsing_walls::draw()
{
  ofBackground (named_colors::red);
  ofSetColor (named_colors::black);

  float displace = 5 + (m_beat_displace * 20);
  
  ofVec2f center_v (m_width / 2.0, m_height / 2.0);
  ofVec2f displace_v, pos;
  ofVec2f curve_ends[2];

  ofFill();
  ofSetPolyMode (OF_POLY_WINDING_POSITIVE);
  ofBeginShape();
  
  for (unsigned int i=0; i < m_walls.size(); i++) {
    pos = m_walls[i];
    
    displace_v = center_v - pos;
    displace_v.normalize();
    displace_v *= (displace * ofRandom(1.0f, 2.0f));

    pos += displace_v;

    ofCurveVertex (pos.x, pos.y);
    
    if (i < 2) {
      curve_ends[i] = pos;
    }
  }

  ofCurveVertex (curve_ends[0].x, curve_ends[0].y);
  ofCurveVertex (curve_ends[1].x, curve_ends[1].y);

  ofEndShape (true);

}

void
pulsing_walls::set_sensitivity (float sensitivity)
{
  m_sensitivity = roundf (ofMap (sensitivity, 0.0, 1.0, 1, 32));
}

float
pulsing_walls::get_displacement()
{
  return m_beat_displace;
}

float
pulsing_walls::get_thickness()
{
  return m_thickness;
}
