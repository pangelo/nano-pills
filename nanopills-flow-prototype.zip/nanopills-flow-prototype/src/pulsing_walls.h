#ifndef PULSING_WALLS_H
#define PULSING_WALLS_H

#include <ofGraphics.h>

//
// Pulsing walls of muscle
//

class pulsing_walls {
 public:
  pulsing_walls();
  ~pulsing_walls();
  
  void setup (float width, float height, int resolution);
  void update ();
  void draw();

  void set_sensitivity (float sensitivity);
  float get_displacement();
  float get_thickness();

 private:
  std::vector<ofVec2f> m_walls;
  float m_width;
  float m_height;
  float m_beat_displace;
  float m_thickness;
  unsigned int m_sensitivity;
};

#endif // PULSING_WALLS_H
