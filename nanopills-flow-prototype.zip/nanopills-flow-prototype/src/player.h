#ifndef PLAYER_H
#define PLAYER_H

#include <ofMath.h>

class player {
 
 public:
 
  player();
  ~player();

  void update (float x, float y);
  void draw();
  void deploy();

 private:
  ofVec2f m_pos;
  enum {TARGET, DEPLOY} m_state;
  std::vector<float> m_payload;
  
};


#endif // PLAYER_H
