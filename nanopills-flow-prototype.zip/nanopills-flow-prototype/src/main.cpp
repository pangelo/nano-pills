#include "ofMain.h"
#include "nano_pills.h"
#include "ofAppGlutWindow.h"

int main( ){

  ofAppGlutWindow window;
  ofSetupOpenGL (&window, 1024, 600, OF_GAME_MODE);

  ofRunApp (new nano_pills());
}
