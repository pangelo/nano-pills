#pragma once

#include "ofMain.h"

#include "pulsing_walls.h"
#include "turbulence.h"
#include "player.h"

class nano_pills : public ofBaseApp{
  
 public:
  
  void setup();
  void update();
  void draw();

  void keyPressed  (int key);
  void keyReleased(int key);
  void mouseMoved(int x, int y );
  void mouseDragged(int x, int y, int button);
  void mousePressed(int x, int y, int button);
  void mouseReleased(int x, int y, int button);
  void windowResized(int w, int h);
  void dragEvent(ofDragInfo dragInfo);
  void gotMessage(ofMessage msg);
  void exit();

 private:

  std::vector<ofVec2f> m_particles;
  ofSoundPlayer m_beat;
  pulsing_walls m_walls;
  player m_player;
  turbulence m_turbulence;
  float m_last_update_time;
};
