#ifndef FIRE_TURBULENCE_H
#define FIRE_TURBULENCE_H

/**
 * \file   turbulence.h
 * \author pangelo <pangelo@void.io>
 * \date   Thu Oct 27 02:52:47 2011
 * 
 * \brief  A simple turbulence model based on scaled curl noise
 * 
 * 
 */

#include <ofMath.h>

class turbulence {
    
 public:

  turbulence();
  ~turbulence();
      
  void set_grid_domain (float min_u, float max_u, float min_v, float max_v);
  void set_grid_steps (float u_steps, float v_steps);
  void set_velocity_scale (float vscale);
  void set_time_scale (float tscale);
  void set_noise_octaves (unsigned int num_octaves);

  // Map arbitrary coordinates to and from the simulation domain
  float map_to_u (float value, float input_min, float input_max);
  float map_to_v (float value, float input_min, float input_max);

  float map_from_u (float value, float output_min, float output_max);
  float map_from_v (float value, float output_min, float output_max);

  ofVec2f map_to_grid (ofVec2f input_coord, float input_min, float input_max);
  ofVec2f clamp_to_grid (ofVec2f pos);

  void update (float frame_delta);
  void reset();

  ofVec2f get_velocity (float u, float v);
  ofVec2f get_velocity (ofVec2f pos);

  float get_simulation_time();

 private:
      
  float m_min_u;
  float m_max_u;
  float m_min_v;
  float m_max_v;
  float m_time_scale;
  float m_vscale;
  float m_sample_steps;
  float m_u_step;
  float m_v_step;
  float m_time;
  unsigned int m_num_octaves;
  
  ofVec2f noise_curl (float u, float v, float t);
  float sh_noise (float u, float v, float t);
};
  
#endif // FIRE_TURBULENCE_H
