#ifndef NAMED_COLORS_H
#define NAMED_COLORS_H

#include <ofColor.h>

//
// The 16 Named Colors
//

namespace named_colors {
  const ofColor black (0, 0, 0);
  const ofColor gray (128, 128, 128);
  const ofColor silver (192, 192, 192);
  const ofColor white (255, 255, 255);
  const ofColor maroon (128, 0, 0);
  const ofColor red (255, 0, 0);
  const ofColor olive (128, 128, 0);
  const ofColor yellow (255, 255, 0);
  const ofColor green (0, 128, 0);
  const ofColor lime (0, 255, 0);
  const ofColor teal (0, 128, 128);
  const ofColor aqua (0, 255, 255);
  const ofColor navy (0, 0, 128);
  const ofColor blue (0, 0, 255);
  const ofColor purple (128, 0, 128);
  const ofColor fuchsia (255, 0, 255);
}

#endif // NAMED_COLORS_H
