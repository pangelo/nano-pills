#include "turbulence.h"

#include "simplexnoise1234.h"

turbulence::turbulence():
  m_min_u (-1.0f),
  m_max_u (1.0f),
  m_min_v (-1.0f),
  m_max_v (1.0f),
  m_time_scale (1.0f),
  m_vscale (1.0f),
  m_u_step ((m_max_u - m_min_u) / 1000),
  m_v_step ((m_max_v - m_min_v) / 1000),
  m_time(0.0f),
  m_num_octaves (1)
{
}

turbulence::~turbulence()
{
}
      
void 
turbulence::set_grid_domain (float min_u, float max_u, float min_v, float max_v)
{
  m_min_u = min_u;
  m_max_u = max_u;
  m_min_v = min_v;
  m_max_v = max_v;
}
    
void 
turbulence::set_grid_steps (float u_steps, float v_steps)
{
  m_u_step = (m_max_u - m_min_u) / u_steps;
  m_v_step = (m_max_v - m_min_v) / v_steps;
}

void 
turbulence::set_velocity_scale (float vscale)
{
  m_vscale = vscale;
}
    
void 
turbulence::set_time_scale (float tscale)
{
  m_time_scale = tscale;
}

void 
turbulence::set_noise_octaves (unsigned int num_octaves)
{
  m_num_octaves = num_octaves;
}

float 
turbulence::map_to_u (float value, float input_min, float input_max)
{
  return ofMap (value, input_min, input_max, m_min_u, m_max_u);
}
    
float 
turbulence::map_to_v (float value, float input_min, float input_max)
{
  return ofMap (value, input_min, input_max, m_min_v, m_max_v);
}

float 
turbulence::map_from_u (float value, float output_min, float output_max)
{
  return ofMap (value, m_min_u, m_max_u, output_min, output_max);
}

float 
turbulence::map_from_v (float value, float output_min, float output_max)
{
  return ofMap (value, m_min_v, m_max_v, output_min, output_max);
}

ofVec2f 
turbulence::map_to_grid (ofVec2f input_coord, float input_min, float input_max)
{
  return ofVec2f (map_to_u (input_coord.x, input_min, input_max),
		  map_to_v (input_coord.y, input_min, input_max));
}

ofVec2f 
turbulence::clamp_to_grid (ofVec2f pos)
{
  return ofVec2f (ofClamp (pos.x, m_min_u, m_max_u), 
		  ofClamp (pos.y, m_min_v, m_max_v));
}

void 
turbulence::update (float frame_delta)
{
  float scaled_delta = frame_delta * m_time_scale;
  
  m_time = m_time + scaled_delta;
}
    
void 
turbulence::reset()
{
  m_time = 0;
}

ofVec2f 
turbulence::get_velocity (float u, float v)
{
  return noise_curl (u, v, m_time) * m_vscale;
}

ofVec2f 
turbulence::get_velocity (ofVec2f pos)
{
  return get_velocity (pos.x, pos.y);
}

float 
turbulence::get_simulation_time() {
  return (m_time / m_time_scale);
}

// Compute the noise curl vector for a potential at (u,v)
ofVec2f 
turbulence::noise_curl (float u, float v, float t)
{
  ofVec2f vel;
  
  vel.x = (sh_noise (u, v + m_v_step, t) - sh_noise (u, v - m_v_step, t));
  vel.y = -(sh_noise (u + m_u_step, v, t) - sh_noise (u - m_u_step, v, t));
  
  return vel;
}

// scaled harmonic noise
float
turbulence::sh_noise (float u, float v, float t) 
{
  float sample = SimplexNoise1234::noise (u,v,t);
  
  float base_octave = min (m_u_step, m_v_step);
  
  for (unsigned int i = 1; i <= m_num_octaves; i++) {
    sample += SimplexNoise1234::noise (u,v, base_octave * i * t) / (2 + i);
  }
      
  return sample;
}

