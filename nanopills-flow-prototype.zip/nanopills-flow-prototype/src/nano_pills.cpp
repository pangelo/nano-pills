#include "nano_pills.h"
#include "named_colors.h"

void nano_pills::setup(){
  m_beat.loadSound ("heartbeat.wav");
  m_beat.setLoop (true);
  m_beat.setMultiPlay (false);
  m_beat.setVolume (1.0f);
  m_beat.play();
  
  m_turbulence.set_velocity_scale (500.0f);
  m_turbulence.set_noise_octaves (3);
  m_turbulence.set_grid_domain (-2.0, 2.0, -1.125, 1.125);

  m_particles.resize(1000);
  std::vector<ofVec2f>::iterator it;
  for (it = m_particles.begin(); it != m_particles.end(); it++) {
    (*it).set (ofRandom (0.0f, ofGetWidth()), ofRandom (0.0f, ofGetHeight()));
  }

  m_walls.setup (ofGetWidth(), ofGetHeight(), 64);
  m_last_update_time = ofGetElapsedTimef();

  ofHideCursor();
  m_player.update(ofGetWidth() / 2.0f, ofGetHeight() / 2.0f);
}

void nano_pills::update(){
  float now = ofGetElapsedTimef(); 
  float delta = now - m_last_update_time;
  m_last_update_time = now;
  
  m_player.update (mouseX, mouseY);
  m_walls.update();
  m_turbulence.update (delta);

  std::vector<ofVec2f>::iterator pos_it;
  float u, v;
  ofVec2f vel, displaced_vel;
  float displacement = m_walls.get_displacement();
  float width = ofGetWidth();
  float height = ofGetHeight();
  float pump_mag = 2 * displacement; 
  float wall_thickness = m_walls.get_thickness();
  for (pos_it = m_particles.begin(); pos_it != m_particles.end(); pos_it++) {
    u = m_turbulence.map_to_u (pos_it->x, 0, ofGetWidth());
    v = m_turbulence.map_to_v (pos_it->y, 0, ofGetHeight());
    vel = m_turbulence.get_velocity (u, v);
    displaced_vel = vel * displacement;

    if (pos_it->x < wall_thickness) {
      pos_it->x = (wall_thickness + pump_mag);
    }
    else if (pos_it->x > (width - wall_thickness)) {
      pos_it->x = ((width - wall_thickness) - pump_mag);
    }

    if (pos_it->y < wall_thickness) {
      pos_it->y = (wall_thickness + pump_mag);
    }
    else if (pos_it->y > (height - wall_thickness)) {
      pos_it->y = ((height - wall_thickness) - pump_mag);
    }

    *pos_it += (0.1 * vel);
    *pos_it += (0.9 * displaced_vel);
  }  
}

void nano_pills::draw(){

  m_walls.draw();

  ofSetColor(named_colors::white);
  glPointSize(10.0f);
  glBegin(GL_POINTS);
  std::vector<ofVec2f>::iterator it;
  for (it = m_particles.begin(); it != m_particles.end(); it++) {
    glVertex2f (it->x, it->y);
  }
  glEnd();

  m_player.draw();
}


void nano_pills::keyPressed(int key){

}


void nano_pills::keyReleased(int key){

}


void nano_pills::mouseMoved(int x, int y ){

}


void nano_pills::mouseDragged(int x, int y, int button){

}


void nano_pills::mousePressed(int x, int y, int button){
  m_player.deploy();
}


void nano_pills::mouseReleased(int x, int y, int button){

}


void nano_pills::windowResized(int w, int h){

}


void nano_pills::gotMessage(ofMessage msg){

}


void nano_pills::dragEvent(ofDragInfo dragInfo){ 

}

void nano_pills::exit() {
  m_beat.unloadSound();
}
